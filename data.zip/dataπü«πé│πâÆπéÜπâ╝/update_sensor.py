import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import random

def random_true_false():
    return bool(random.getrandbits(1))

cred = credentials.Certificate("ramenlove-firebase-adminsdk-906kv-752fcf6d96.json") # ダウンロードした秘密鍵
firebase_admin.initialize_app(cred)

db = firestore.client()

for i in range(40):
    doc_name = 'outer' + str(i)
    doc_ref = db.collection('trains').document(str(doc_name))
    doc_ref.update({
        'sensor1': [random_true_false(), random_true_false()],
        'sensor2': [random_true_false(), random_true_false()],
        'sensor3': [random_true_false(), random_true_false()],
        'sensor4': [random_true_false(), random_true_false()],
        'sensor5': [random_true_false(), random_true_false()],
        'sensor6': [random_true_false(), random_true_false()],
    })

for j in range(50):
    doc_name = 'inner' + str(j)
    doc_ref = db.collection('trains').document(str(doc_name))
    doc_ref.update({
        'sensor1': [random_true_false(), random_true_false()],
        'sensor2': [random_true_false(), random_true_false()],
        'sensor3': [random_true_false(), random_true_false()],
        'sensor4': [random_true_false(), random_true_false()],
        'sensor5': [random_true_false(), random_true_false()],
        'sensor6': [random_true_false(), random_true_false()],
    })

