import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import random

def time_check(x):
    if x >= 60:
        x = (x // 60) * 100 + (x % 60) 
    return x

def random_true_false():
    return bool(random.getrandbits(1))

cred = credentials.Certificate("ramenlove-firebase-adminsdk-906kv-752fcf6d96.json") # ダウンロードした秘密鍵
firebase_admin.initialize_app(cred)

db = firestore.client()

for i in range(50):
    interval = 12
    start_time = 1000
    save = 'outer' + str(i).zfill(2)
    doc_ref = db.collection('trains').document(str(save))
    doc_ref.set({
        'around' : "外回り",
        'sensor1': [random_true_false(), random_true_false()],
        'sensor2': [random_true_false(), random_true_false()],
        'sensor3': [random_true_false(), random_true_false()],
        'sensor4': [random_true_false(), random_true_false()],
        'sensor5': [random_true_false(), random_true_false()],
        'sensor6': [random_true_false(), random_true_false()],
        'time_tables': [
            {'station_name': "東京", 'stop_time': (start_time + time_check(interval * i))},
            {'station_name': "有楽町", 'stop_time': (start_time + time_check(interval * i + 2))},
            {'station_name': "新橋", 'stop_time': (start_time + time_check(interval * i + 4))},
            {'station_name': "浜松町", 'stop_time': (start_time + time_check(interval * i + 6))},
            {'station_name': "田町", 'stop_time': (start_time + time_check(interval * i + 8))},
            {'station_name': "高輪ゲートウェイ", 'stop_time': (start_time + time_check(interval * i + 11))},
            {'station_name': "品川", 'stop_time': (start_time + time_check(interval * i + 13))},
            {'station_name': "大崎", 'stop_time': (start_time + time_check(interval * i) + 15)},
            {'station_name': "五反田", 'stop_time': (start_time + time_check(interval * i + 16))},
            {'station_name': "目黒", 'stop_time': (start_time + time_check(interval * i + 19))},
            {'station_name': "恵比寿", 'stop_time': (start_time + time_check(interval * i + 21))},
            {'station_name': "渋谷", 'stop_time': (start_time + time_check(interval * i + 24))},
            {'station_name': "原宿", 'stop_time': (start_time + time_check(interval * i + 26))},
            {'station_name': "代々木", 'stop_time': (start_time + time_check(interval * i + 30))},
            {'station_name': "新宿", 'stop_time': (start_time + time_check(interval * i + 33))},
            {'station_name': "新大久保", 'stop_time': (start_time + time_check(interval * i + 35))},
            {'station_name': "高田馬場", 'stop_time': (start_time + time_check(interval * i + 37))},
            {'station_name': "目白", 'stop_time': (start_time + time_check(interval * i + 39))},
            {'station_name': "池袋", 'stop_time': (start_time + time_check(interval * i + 41))},
            {'station_name': "大塚", 'stop_time': (start_time + time_check(interval * i + 44))},
            {'station_name': "巣鴨", 'stop_time': (start_time + time_check(interval * i + 46))},
            {'station_name': "駒込", 'stop_time': (start_time + time_check(interval * i + 48))},
            {'station_name': "田端", 'stop_time': (start_time + time_check(interval * i + 50))},
            {'station_name': "西日暮里", 'stop_time': (start_time + time_check(interval * i + 52))},
            {'station_name': "日暮里", 'stop_time': (start_time + time_check(interval * i + 54))},
            {'station_name': "鶯谷", 'stop_time': (start_time + time_check(interval * i + 55))},
            {'station_name': "上野", 'stop_time': (start_time + time_check(interval * i + 58))},
            {'station_name': "御徒町", 'stop_time': (start_time + time_check(interval * i + 59))},
            {'station_name': "秋葉原", 'stop_time': (start_time + time_check(interval * i + 61))},
            {'station_name': "神田", 'stop_time': (start_time + time_check(interval * i + 63))},
        ]
    })

